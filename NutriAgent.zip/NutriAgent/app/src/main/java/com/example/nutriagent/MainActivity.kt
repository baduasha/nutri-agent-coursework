package com.example.nutriagent

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.nutriagent.ui.theme.NutriAgentTheme
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NutriAgentTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MainScreen()
                }
            }
        }
    }
}

@Composable
fun MainScreen() {
    var statusText by remember { mutableStateOf("Добавьте изображение блюда для анализа") }
    var grams by remember { mutableStateOf(250f) }
    var kcalPer100 by remember { mutableStateOf(200) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var showCamera by remember { mutableStateOf(false) }
    var capturedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    var isAnalyzing by remember { mutableStateOf(false) }
    var detectedLabel by remember { mutableStateOf<String?>(null) }
    var confidence by remember { mutableStateOf<Double?>(null) }

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                    PackageManager.PERMISSION_GRANTED
        )
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        showCamera = granted
        statusText = if (granted) "Разрешение на камеру получено" else "Доступ к камере запрещён"
    }

    fun analyzeImage(bmp: Bitmap) {
        isAnalyzing = true
        statusText = "Выполняется анализ изображения…"

        scope.launch {
            try {
                val stream = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 90, stream)
                val bytes = stream.toByteArray()

                val requestBody = bytes.toRequestBody("image/jpeg".toMediaType())
                val part = MultipartBody.Part.createFormData(
                    name = "image",
                    filename = "photo.jpg",
                    body = requestBody
                )

                val result = ApiClient.api.analyze(part)

                detectedLabel = result.label
                confidence = result.confidence
                kcalPer100 = result.kcalPer100

                statusText = "Анализ завершён"
            } catch (e: Exception) {
                statusText = "Ошибка подключения к серверу"
                e.printStackTrace()
            } finally {
                isAnalyzing = false
            }
        }
    }

    val pickPhotoLauncher = rememberLauncherForActivityResult(
        contract = PickVisualMedia()
    ) { uri: Uri? ->
        if (uri == null) {
            statusText = "Изображение не выбрано"
            return@rememberLauncherForActivityResult
        }

        try {
            val inputStream = context.contentResolver.openInputStream(uri)
            val bmp = android.graphics.BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (bmp == null) {
                statusText = "Не удалось прочитать изображение"
                return@rememberLauncherForActivityResult
            }

            capturedBitmap = bmp
            analyzeImage(bmp)
        } catch (e: Exception) {
            statusText = "Ошибка обработки изображения"
            e.printStackTrace()
            isAnalyzing = false
        }
    }

    if (showCamera) {
        CameraScreen(
            onPhotoCaptured = { bmp ->
                capturedBitmap = bmp
                showCamera = false
                analyzeImage(bmp)
            },
            onClose = {
                showCamera = false
                statusText = "Сеанс камеры завершён"
            }
        )
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Агент-нутрициолог",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Text(text = statusText, style = MaterialTheme.typography.bodyLarge)

        Button(
            onClick = {
                if (hasCameraPermission) {
                    showCamera = true
                } else {
                    statusText = "Запрос разрешения на камеру…"
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Сделать фото")
        }

        OutlinedButton(
            onClick = {
                pickPhotoLauncher.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly))
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Выбрать изображение")
        }

        capturedBitmap?.let { bmp ->
            Text("Последнее изображение", style = MaterialTheme.typography.titleMedium)

            detectedLabel?.let { label ->
                Text("Результат распознавания: $label", style = MaterialTheme.typography.bodyLarge)
            }

            confidence?.let { conf ->
                Text("Достоверность: ${"%.2f".format(conf)}", style = MaterialTheme.typography.bodyMedium)
            }

            if (isAnalyzing) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator()
                    Text("Обработка…")
                }
            }

            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = "Изображение блюда",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
            )

            OutlinedButton(
                onClick = { showCamera = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Сделать новое фото")
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Расчёт калорийности", fontWeight = FontWeight.SemiBold)

                Text("Масса порции: ${grams.toInt()} г")
                Slider(
                    value = grams,
                    onValueChange = { grams = it },
                    valueRange = 50f..800f
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Ккал на 100 г")
                    Text("$kcalPer100")
                }

                Text(
                    text = "Общая калорийность: ${(grams * kcalPer100 / 100f).toInt()} ккал",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
    }
}
