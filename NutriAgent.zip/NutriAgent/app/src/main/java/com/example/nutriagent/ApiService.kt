package com.example.nutriagent

import okhttp3.MultipartBody
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

data class AnalyzeResponse(
    val ok: Boolean,
    val label: String,
    val kcalPer100: Int,
    val confidence: Double
)

interface ApiService {

    @Multipart
    @POST("/analyze")
    suspend fun analyze(
        @Part image: MultipartBody.Part
    ): AnalyzeResponse
}

object ApiClient {
    val api: ApiService by lazy {
        Retrofit.Builder()
            // ВАЖНО: для эмулятора Android
            .baseUrl("http://10.0.2.2:8000/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
